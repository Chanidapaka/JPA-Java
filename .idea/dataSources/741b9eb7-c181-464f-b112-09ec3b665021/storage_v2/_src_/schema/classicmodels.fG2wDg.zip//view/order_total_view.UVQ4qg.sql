create definer = root@localhost view order_total_view as
select `classicmodels`.`orderdetails`.`orderNumber`                                                         AS `ordernumber`,
       sum((`classicmodels`.`orderdetails`.`quantityOrdered` *
            `classicmodels`.`orderdetails`.`priceEach`))                                                    AS `total_amount`
from `classicmodels`.`orderdetails`
group by `classicmodels`.`orderdetails`.`orderNumber`;

